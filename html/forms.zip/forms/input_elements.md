#input elements

##Types

*text - Write any free form text
*email - Forces user to add an e-mail address
*password - Let's the user write an encrypted password
*date - Let's you a pick a specific date
*checkbox - Let's you pick an option of set values

